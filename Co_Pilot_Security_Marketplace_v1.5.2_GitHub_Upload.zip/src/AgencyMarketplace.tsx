import { useEffect, useMemo, useState, type ReactNode } from 'react'
import {
  AlertTriangle, BadgeCheck, BarChart3, Bell, BriefcaseBusiness, Building2, ClipboardList,
  CalendarClock, Check, ChevronDown, ChevronRight, CircleDollarSign, Clock3,
  Crosshair, Filter, Flame, Gauge, Layers3, MapPin, MessageSquare, Navigation,
  Radio, Search, Settings, ShieldCheck, Siren, SlidersHorizontal, Users, Wifi, Zap, Bug, Database, LockKeyhole, X
} from 'lucide-react'
import { useAuth, type AppRole } from './modules/auth/AuthProvider'
import type { DeveloperAccessMode } from './DeveloperPortalSwitcher'
import { acceptMarketplaceJob, getAgencyContext, getAgencyMarketplace, subscribeToMarketplace, type MarketplaceJobRow } from './modules/marketplace/marketplaceRepository'

type JobKind = 'standard' | 'priority' | 'emergency'
type Job = { id:string; title:string; client:string; address:string; distance:number; eta:number; duration:number; kind:JobKind; property:string; price:number; x:number; y:number; live?:boolean }
type Guard = { id:number; name:string; initials:string; distance:number; status:'available'|'on-mission'|'reserved'|'offline'; x:number; y:number }
type Activity = { id:number; time:string; type:'new'|'accepted'|'emergency'|'assigned'; title:string; location:string }

const initialJobs:Job[] = [
  {id:'101',title:'Immediate Property Check',client:'Riverview Commerce Center',address:'10114 Bloomingdale Ave, Riverview, FL',distance:3.4,eta:9,duration:45,kind:'standard',property:'Retail',price:85,x:18,y:34},
  {id:'102',title:'Vacant Home Patrol',client:'South Fork Community',address:'7622 Summerfield Blvd, Riverview, FL',distance:4.7,eta:12,duration:60,kind:'priority',property:'Residential',price:110,x:42,y:35},
  {id:'103',title:'Construction Site Sweep',client:'Riverview Build Site',address:'13209 U.S. Hwy 301, Riverview, FL',distance:6.9,eta:16,duration:60,kind:'priority',property:'Construction',price:125,x:32,y:57},
  {id:'104',title:'Emergency Alarm Response',client:'Progress Village Plaza',address:'10902 Big Bend Rd, Riverview, FL',distance:1.2,eta:4,duration:30,kind:'emergency',property:'Commercial',price:150,x:74,y:24},
]

const incomingJobs:Job[] = [
  {id:'105',title:'Evening Apartment Patrol',client:'Bloomingdale Apartments',address:'3950 Bell Shoals Rd, Valrico, FL',distance:5.2,eta:13,duration:45,kind:'standard',property:'Multifamily',price:95,x:52,y:24},
  {id:'106',title:'Priority Business Check',client:'Brandon Medical Plaza',address:'2020 W Brandon Blvd, Brandon, FL',distance:7.8,eta:18,duration:40,kind:'priority',property:'Medical',price:135,x:27,y:44},
]

const initialActivity:Activity[] = [
  {id:1,time:'11:46 AM',type:'new',title:'New job posted',location:'Riverview Commerce Center'},
  {id:2,time:'11:45 AM',type:'accepted' as const,title:'Agency accepted',location:'Vacant Home Patrol'},
  {id:3,time:'11:43 AM',type:'emergency',title:'New emergency job',location:'Progress Village Plaza'},
]

const guards:Guard[] = [
  {id:1,name:'Marcus',initials:'MR',distance:.8,status:'available',x:58,y:31},
  {id:2,name:'Jalen',initials:'JL',distance:1.6,status:'available',x:69,y:47},
  {id:3,name:'Tyler',initials:'TY',distance:2.3,status:'available',x:22,y:64},
  {id:4,name:'Derrick',initials:'DL',distance:3.1,status:'available',x:43,y:77},
  {id:5,name:'Kevin',initials:'KV',distance:4.2,status:'available',x:61,y:83},
  {id:6,name:'Rico',initials:'RC',distance:4.6,status:'available',x:78,y:69},
  {id:7,name:'Anthony',initials:'AN',distance:5.1,status:'available',x:84,y:39},
  {id:8,name:'Nia',initials:'NB',distance:3.8,status:'reserved',x:35,y:18},
  {id:9,name:'Caleb',initials:'CS',distance:6.1,status:'on-mission',x:15,y:76},
  {id:10,name:'Andre',initials:'AK',distance:8.4,status:'offline',x:88,y:82},
]

const navItems = [
  ['marketplace','Marketplace','Find Opportunities',Crosshair],['operations','Operations','Active Missions',Radio],['scheduled','Scheduled','Upcoming Jobs',CalendarClock],['guards','Guards','Manage Your Team',Users],['assignments','Assignments','Won Marketplace Jobs',ClipboardList],['reports','Reports','Mission Reports',BriefcaseBusiness],['analytics','Analytics','Performance Center',BarChart3],['messages','Messages','Inbox & Alerts',MessageSquare],['settings','Settings','Agency Settings',Settings],
] as const
type Tab = typeof navItems[number][0]

export default function AgencyMarketplace({developerMode=false,accessMode='live',viewedRole='agency_admin'}:{developerMode?:boolean;accessMode?:DeveloperAccessMode;viewedRole?:AppRole}){
  const { mode, role, user, status, phase } = useAuth()
  const [tab,setTab]=useState<Tab>('marketplace')
  const [jobs,setJobs]=useState(initialJobs)
  const [accepted,setAccepted]=useState<Job[]>([])
  const [agencyId,setAgencyId]=useState<string | null>(null)
  const [agencyName,setAgencyName]=useState('Alpha Force Security')
  const [claimingId,setClaimingId]=useState<string | null>(null)
  const [filter,setFilter]=useState<'all'|JobKind>('all')
  const [toast,setToast]=useState('')
  const [activity,setActivity]=useState<Activity[]>(initialActivity)
  const [incomingIndex,setIncomingIndex]=useState(0)
  const [diagnosticsOpen,setDiagnosticsOpen]=useState(false)
  const [lastError,setLastError]=useState<string | null>(null)
  const [realtimeState,setRealtimeState]=useState<'idle'|'connected'|'preview'>('idle')
  const isRoleMatch=role==='agency_admin'
  const isPreview=developerMode && (accessMode==='preview' || !isRoleMatch)
  const filtered=useMemo(()=>filter==='all'?jobs:jobs.filter(j=>j.kind===filter),[jobs,filter])
  const available=guards.filter(g=>g.status==='available')

  const mapLiveJob=(row:MarketplaceJobRow,index:number):Job=>({
    id:row.id,title:row.title,client:row.client?.display_name||'Marketplace Client',
    address:row.property?.address||'Verified property',distance:Number((1.2+(index%7)*.9).toFixed(1)),
    eta:4+(index%6)*3,duration:row.duration_minutes,kind:row.priority,
    property:row.property?.name||'Property',price:row.payout_cents?Math.round(row.payout_cents/100):0,
    x:18+(index*17)%68,y:22+(index*13)%58,live:true,
  })

  const loadMarketplace=async(currentAgencyId:string)=>{
    try {
    const data=await getAgencyMarketplace(currentAgencyId)
    setJobs(data.open.map(mapLiveJob))
    setAccepted(data.claimed.map(mapLiveJob))
    setLastError(null)
    } catch (error) {
      const message=error instanceof Error?error.message:'Unable to load marketplace.'
      setLastError(message)
      throw error
    }
  }

  useEffect(()=>{
    if(isPreview||mode!=='supabase'||!user?.id)return
    let active=true
    getAgencyContext(user.id).then(context=>{
      if(!active)return
      setAgencyId(context.agencyId);setAgencyName(context.name)
      return loadMarketplace(context.agencyId)
    }).catch(error=>{const message=error instanceof Error?error.message:'Unable to load marketplace.';setLastError(message);setToast(developerMode?`Marketplace blocked: ${message}`:'Unable to load marketplace.')})
    return()=>{active=false}
  },[mode,user?.id,isPreview,developerMode])

  useEffect(()=>{
    if(isPreview){setRealtimeState('preview');return}
    if(mode!=='supabase'||!agencyId)return
    setRealtimeState('connected')
    return subscribeToMarketplace(()=>{void loadMarketplace(agencyId)})
  },[mode,agencyId,isPreview])

  useEffect(()=>{
    if((mode==='supabase'&&!isPreview)||incomingIndex>=incomingJobs.length) return
    const timer=window.setTimeout(()=>{
      const job=incomingJobs[incomingIndex]
      setJobs(v=>[job,...v])
      const nextActivity: Activity = {
        id: Date.now(),
        time: 'Now',
        type: job.kind === 'emergency' ? 'emergency' : 'new',
        title: job.kind === 'priority' ? 'New priority job' : 'New job posted',
        location: job.client,
      }
      setActivity(current => [nextActivity, ...current].slice(0, 6))
      setToast(`${job.title} just entered the marketplace.`)
      setIncomingIndex(i=>i+1)
    },9000+incomingIndex*6000)
    return ()=>window.clearTimeout(timer)
  },[incomingIndex,mode,isPreview])

  useEffect(()=>{if(!toast)return;const timer=window.setTimeout(()=>setToast(''),3200);return()=>window.clearTimeout(timer)},[toast])

  const accept=async(job:Job)=>{
    if(claimingId)return
    if(isPreview){setToast(isRoleMatch?'Preview Mode: claim simulated only.':'Preview Mode: signed in as Client. Switch to an approved Agency account for Live Test.');return}
    if(mode==='supabase'){
      if(!agencyId){setToast(`Signed in as ${role?.replace('_',' ')??'user'}. Agency actions require an approved Agency account.`);return}
      setClaimingId(job.id)
      try{
        const result=await acceptMarketplaceJob(job.id,agencyId)
        if(!result.accepted){setJobs(v=>v.filter(j=>j.id!==job.id));setToast('Another agency claimed this mission first.');return}
        await loadMarketplace(agencyId)
        setToast(`${job.title} is now owned by ${agencyName}.`)
      }catch(error){setToast(error instanceof Error?error.message:'Unable to claim mission.')}
      finally{setClaimingId(null)}
      return
    }
    setJobs(v=>v.filter(j=>j.id!==job.id));setAccepted(v=>[job,...v])
    setActivity(current => [{id:Date.now(),time:'Now',type:'accepted' as const,title:`${agencyName} accepted`,location:job.title},...current].slice(0,6))
    setToast(`${job.title} locked to ${agencyName} and moved to Operations.`)
  }
  return <div className="agency-app premium-agency">
    {developerMode&&<div className={`developer-runtime-banner ${isPreview?'preview':'live'}`}><div><CodeStatus preview={isPreview}/><span><strong>{isPreview?'PREVIEW MODE':'LIVE TEST'}</strong><small>Authenticated: {role?.replace('_',' ')??'unknown'} · Viewing: {viewedRole.replace('_',' ')}</small></span></div><button onClick={()=>setDiagnosticsOpen(true)}><Bug/>Diagnostics</button></div>}
    {diagnosticsOpen&&<DeveloperDiagnostics onClose={()=>setDiagnosticsOpen(false)} authRole={role} viewedRole={viewedRole} accountStatus={status} authPhase={phase} agencyId={agencyId} agencyName={agencyName} preview={isPreview} realtimeState={realtimeState} lastError={lastError} jobs={jobs} accepted={accepted}/>}
    {toast&&<div className="market-toast"><Check/>{toast}</div>}
    <aside className="agency-sidebar premium-sidebar">
      <div className="premium-logo"><ShieldCheck/><div><strong>CO PILOT</strong><span>SECURITY MARKETPLACE</span></div></div>
      <nav>{navItems.map(([id,label,sub,Icon])=><button key={id} className={tab===id?'active':''} onClick={()=>setTab(id)}><Icon/><span><strong>{label}</strong><small>{sub}</small></span>{id==='marketplace'&&<b>{jobs.length}</b>}{id==='operations'&&<b>{accepted.length+2}</b>}{id==='scheduled'&&<b>3</b>}{id==='guards'&&<b>10</b>}{id==='reports'&&<b>1</b>}{id==='messages'&&<b>4</b>}</button>)}</nav>
      <div className="agency-mini-card"><div className="mini-agency"><span>AF</span><div><strong>{agencyName}</strong><small><BadgeCheck/>Verified Agency</small></div></div><div className="mini-stats"><span>Total Guards <b>10</b></span><span>Available <b>7</b></span><span>On Mission <b>2</b></span><span>Reserved <b>1</b></span></div></div>
      <div className="sidebar-version">v1.5.2 <span className={`backend-mode ${mode}`}><i/>{mode === 'supabase' ? 'Supabase Connected' : 'Mock Mode'}</span></div>
    </aside>

    <header className="agency-topbar premium-topbar">
      <div className="page-title"><div className="foundation-status"><span className={mode}><Wifi/>{mode === 'supabase' ? 'SUPABASE CONNECTED' : 'BACKEND READY · MOCK DATA'}</span><small>{role ?? 'role pending'}</small></div><h1>{tab==='marketplace'?'Marketplace':'Operations'}</h1><p>{tab==='marketplace'?'Find. Compete. Win. Protect.':'Manage active missions without leaving the market.'}</p></div>
      <div className="top-kpis"><Kpi icon={<CircleDollarSign/>} label="OPEN JOBS" value={jobs.length} tone="gold"/><Kpi icon={<Flame/>} label="PRIORITY" value={jobs.filter(j=>j.kind==='priority').length} tone="orange"/><Kpi icon={<Siren/>} label="EMERGENCY" value={jobs.filter(j=>j.kind==='emergency').length} tone="red"/><Kpi icon={<Users/>} label="ACTIVE JOBS" value={accepted.length+2} tone="green"/><Kpi icon={<ShieldCheck/>} label="ONLINE GUARDS" value={9} tone="blue"/></div>
      <div className="top-actions"><button className="icon-button"><Bell/><i>4</i></button><button className="icon-button"><MessageSquare/></button><button className="profile-pill"><span>AF</span><div><strong>{agencyName}</strong><small>Agency Admin</small></div><ChevronDown/></button></div>
    </header>

    <main className="agency-main premium-main">
      {tab==='marketplace'?<Marketplace jobs={jobs} filtered={filtered} filter={filter} setFilter={setFilter} accept={job=>void accept(job)} available={available} activity={activity}/>:tab==='operations'?<Operations accepted={accepted} onMarketplace={()=>setTab('marketplace')}/>:<Placeholder tab={tab}/>} 
    </main>
  </div>
}

function Kpi({icon,label,value,tone}:{icon:ReactNode,label:string,value:number,tone:string}){return <div className={`top-kpi ${tone}`}><span>{icon}</span><div><small>{label}</small><strong>{value}</strong></div></div>}

function Marketplace({jobs,filtered,filter,setFilter,accept,available,activity}:{jobs:Job[];filtered:Job[];filter:'all'|JobKind;setFilter:(v:'all'|JobKind)=>void;accept:(j:Job)=>void;available:Guard[];activity:Activity[]}){
 return <div className="premium-dashboard">
  <section className="mobile-market-kpis" aria-label="Marketplace status">
    <div className="gold"><small>OPEN</small><strong>{jobs.length}</strong></div>
    <div className="orange"><small>PRIORITY</small><strong>{jobs.filter(j=>j.kind==='priority').length}</strong></div>
    <div className="red"><small>EMERGENCY</small><strong>{jobs.filter(j=>j.kind==='emergency').length}</strong></div>
    <div className="green"><small>ACTIVE</small><strong>2</strong></div>
    <div className="blue"><small>GUARDS</small><strong>9</strong></div>
  </section>
  <section className="live-map-panel premium-panel">
   <div className="premium-panel-head"><div><strong>LIVE MARKETPLACE MAP</strong><span><i/>LIVE</span></div><button><Layers3/>Layers<ChevronDown/></button></div>
   <div className="map-filter-row">{(['all','standard','priority','emergency'] as const).map(v=><button key={v} className={filter===v?'active':''} onClick={()=>setFilter(v)}>{v==='all'?'All':v==='standard'?'Open Jobs':v}</button>)}<button onClick={()=>setFilter('all')}>My Guards</button></div>
   <div className="premium-map"><div className="route-line r1"/><div className="route-line r2"/><div className="route-line r3"/><span className="map-city c1">RIVERVIEW</span><span className="map-city c2">PROGRESS VILLAGE</span><span className="map-city c3">SOUTHSHORE</span>{filtered.map(j=><div key={j.id} className={`premium-job-pin ${j.kind}`} style={{left:`${j.x}%`,top:`${j.y}%`}}>{j.kind==='emergency'?<Siren/>:j.kind==='priority'?<Zap/>:<BriefcaseBusiness/>}<span>{j.distance} mi</span></div>)}{guards.filter(g=>g.status!=='offline').map(g=><div key={g.id} className={`premium-guard-pin ${g.status}`} style={{left:`${g.x}%`,top:`${g.y}%`}}><Users/><span>{g.name}<small>{g.distance} mi</small></span></div>)}<div className="map-zoom"><button>+</button><button>−</button><button><Crosshair/></button></div><div className="map-key"><span><i className="gold"/>Open Job</span><span><i className="orange"/>Priority</span><span><i className="red"/>Emergency</span><span><i className="green"/>My Guards</span></div></div>
  </section>

  <section className="opportunities premium-panel"><div className="premium-panel-head"><div><strong>OPEN OPPORTUNITIES <b>{jobs.length}</b></strong></div><button>Nearest<ChevronDown/></button></div><div className="premium-job-list">{filtered.map(j=><article key={j.id} className={`premium-job-card ${j.kind}`}><div className="job-card-top"><span className={`kind-chip ${j.kind}`}>{j.kind==='emergency'?<Siren/>:j.kind==='priority'?<Zap/>:<BriefcaseBusiness/>}{j.kind==='standard'?'Open Job':j.kind}</span><span>{j.distance} mi<small>ETA {j.eta} min</small></span></div><h3>{j.title}</h3><p>{j.client}<br/>{j.address}</p><div className="job-card-meta"><span><Building2/>{j.property}</span><span><Clock3/>{j.duration} min</span><span><Users/>1 Guard</span></div><div className="job-card-action"><strong>{j.price>0?`$${j.price}`:'Mission'}</strong><button onClick={()=>accept(j)}>Claim Mission</button></div></article>)}</div></section>

  <aside className="right-rail"><section className="capacity-panel premium-panel"><div className="premium-panel-head"><strong>AGENCY CAPACITY</strong></div><div className="capacity-content"><div className="capacity-ring"><span><strong>7</strong><small>Available</small></span></div><div className="capacity-breakdown"><span>Total Guards <b>10</b></span><span>Available <b>7</b></span><span>On Mission <b>2</b></span><span>Reserved <b>1</b></span><span>Offline <b>0</b></span></div></div></section><section className="active-panel premium-panel"><div className="premium-panel-head"><strong>ACTIVE OPERATIONS <b>2</b></strong><button>View All</button></div>{['Retail Store Patrol','Parking Lot Patrol'].map((t,i)=><div className="mini-operation" key={t}><div><small>#A-10{25+i}</small><span>ON MISSION</span></div><strong>{t}</strong><p>{i?'Riverview Plaza':'South Fork Community'}</p><div className="mission-person"><span>{i?'JL':'MR'}</span><div><strong>{i?'Jalen':'Marcus'}</strong><small>{i?'On Site':'En Route'}</small></div><b>{i?'18':'5'} min</b></div><div className="mission-bar"><i style={{width:i?'20%':'33%'}}/></div></div>)}</section><section className="activity-panel premium-panel"><div className="premium-panel-head"><strong>MARKETPLACE ACTIVITY</strong><span>Live Feed</span></div>{activity.map(a=><div className="activity-row" key={a.id}><span className={a.type==='emergency'?'danger':''}>{a.type==='emergency'?<Siren/>:a.type==='accepted'?<Check/>:a.type==='assigned'?<Users/>:<BriefcaseBusiness/>}</span><small>{a.time}</small><div><strong>{a.title}</strong><p>{a.location}</p></div></div>)}</section></aside>

  <section className="bottom-strip premium-panel"><div className="available-guards"><div className="strip-title"><strong>AVAILABLE GUARDS <b>7</b></strong><button>View All</button></div><div className="guard-row">{available.slice(0,7).map(g=><div className="guard-face" key={g.id}><span>{g.initials}</span><strong>{g.name}</strong><small>{g.distance} mi</small></div>)}</div></div><div className="quick-actions"><div className="strip-title"><strong>QUICK ACTIONS</strong></div><div><button className="em"><Siren/>Emergency Center</button><button><Radio/>Broadcast</button><button><Users/>Guard Check-In</button><button><MessageSquare/>New Message</button></div></div></section>
 </div>
}

function Operations({accepted,onMarketplace}:{accepted:Job[];onMarketplace:()=>void}){const active=[...accepted,{...initialJobs[0],title:'Nightly Retail Patrol'}];return <section className="operations-page"><div className="operations-heading"><div><span className="eyebrow">LIVE OPERATIONS</span><h1>Work won. Teams moving.</h1><p>Manage active assignments while marketplace access stays open.</p></div><button onClick={onMarketplace}><Crosshair/>Return to Marketplace</button></div><div className="operations-capacity-banner"><div><Users/><span><strong>7 guards remain available</strong><small>Your agency can continue accepting marketplace jobs.</small></span></div><button onClick={onMarketplace}>View open jobs<ChevronRight/></button></div><div className="operations-grid">{active.map((j,i)=><article className="operation-card" key={`${j.id}-${i}`}><div className="operation-status"><span className={i===active.length-1?'active':'awaiting'}>{i===active.length-1?'Mission Active':'Awaiting Assignment'}</span><small>JOB #{j.id}</small></div><h3>{j.title}</h3><p><MapPin/>{j.address}</p><div className="operation-progress"><i style={{width:i===active.length-1?'62%':'12%'}}/></div><div className="operation-footer"><div className="guard-avatar">{i===active.length-1?'MR':'—'}</div><div><small>{i===active.length-1?'ASSIGNED GUARD':'NEXT ACTION'}</small><strong>{i===active.length-1?'Marcus Reed':'Assign available guard'}</strong></div><button>{i===active.length-1?'Open Mission':'Assign'}<ChevronRight/></button></div></article>)}</div></section>}
function Placeholder({tab}:{tab:string}){return <section className="market-placeholder"><div><Building2/></div><span className="eyebrow">MARKETPLACE FOUNDATION</span><h1>{tab[0].toUpperCase()+tab.slice(1)}</h1><p>This workspace will connect to the same marketplace, capacity, and operations engine.</p></section>}

function CodeStatus({preview}:{preview:boolean}){return preview?<LockKeyhole/>:<Database/>}
function DeveloperDiagnostics({onClose,authRole,viewedRole,accountStatus,authPhase,agencyId,agencyName,preview,realtimeState,lastError,jobs,accepted}:{onClose:()=>void;authRole:AppRole|null;viewedRole:AppRole;accountStatus:string|null;authPhase:string;agencyId:string|null;agencyName:string;preview:boolean;realtimeState:string;lastError:string|null;jobs:Job[];accepted:Job[]}){
  const selected=accepted[0]??jobs[0]
  const Row=({label,value,state='neutral'}:{label:string;value:string;state?:'good'|'warn'|'bad'|'neutral'})=><div className="diagnostic-row"><span>{label}</span><strong className={state}>{value}</strong></div>
  return <div className="developer-diagnostics-scrim" onClick={onClose}><aside className="developer-diagnostics" onClick={e=>e.stopPropagation()}><header><div><Bug/><span><strong>Developer Diagnostics</strong><small>v1.5.2 runtime inspection</small></span></div><button onClick={onClose}><X/></button></header><section><h3>Identity & Access</h3><Row label="Authenticated role" value={authRole?.replace('_',' ')??'unknown'} state={authRole==='agency_admin'?'good':'warn'}/><Row label="Viewing portal" value={viewedRole.replace('_',' ')}/><Row label="Access mode" value={preview?'Preview — writes blocked':'Live Test — real permissions'} state={preview?'warn':'good'}/><Row label="Account status" value={accountStatus??'unknown'} state={accountStatus==='approved'?'good':'warn'}/><Row label="Auth phase" value={authPhase} state={authPhase==='ready'?'good':'warn'}/></section><section><h3>Marketplace Health</h3><Row label="Agency record" value={agencyId?`${agencyName} · ${agencyId.slice(0,8)}…`:'Not resolved'} state={agencyId?'good':'bad'}/><Row label="Marketplace query" value={lastError?`Failed: ${lastError}`:(preview?'Simulated data':'Connected')} state={lastError?'bad':preview?'warn':'good'}/><Row label="Realtime" value={realtimeState} state={realtimeState==='connected'?'good':realtimeState==='preview'?'warn':'neutral'}/><Row label="Open missions" value={String(jobs.length)}/><Row label="Claimed missions" value={String(accepted.length)}/></section><section><h3>Mission Inspector</h3>{selected?<><Row label="Mission ID" value={selected.id}/><Row label="Title" value={selected.title}/><Row label="Current state" value={accepted.some(j=>j.id===selected.id)?'claimed':'open'} state="good"/><Row label="Priority" value={selected.kind}/><Row label="Property" value={selected.address}/></>:<p className="diagnostic-empty">No mission is available to inspect.</p>}</section>{lastError&&<section className="diagnostic-error"><h3>Last Supabase Error</h3><code>{lastError}</code></section>}</aside></div>
}
